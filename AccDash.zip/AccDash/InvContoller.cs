using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class TsdashController : ControllerBase
{
    [HttpGet("invoices")]
    public IActionResult GetInvoices()
    {
        var invoices = new[]
        {
            new { InvoiceNumber = "INV001", Client = "Client A", Amount = 2000.00, Status = "Paid", DueDate = "2024-09-01" },
            new { InvoiceNumber = "INV002", Client = "Client B", Amount = 1500.00, Status = "Pending", DueDate = "2024-09-15" }
        };

        return Ok(new { Invoices = invoices });
    }
}
